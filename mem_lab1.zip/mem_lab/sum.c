#include<stdio.h>
#include<stdlib.h>

#define COLS 1000
#define ROWS 1000

int sum_array_rows(int** a)
{
    int sum1 = 0;

    for (int row = 0; row < ROWS; row++)
    {
        for (int col = 0; col < COLS; col++){
            sum1 += a[row][col];
        }
    }
    
	return sum1;
}

int sum_array_cols(int** a)
{
	int sum2 = 0;

    for (int col = 0; col < COLS; col++)
    {
        for (int row = 0; row < ROWS; row++){
            sum2 += a[row][col];
        }
    }
    
	return sum2;
}

int main()
{
    int** a;
    int i, j;

    a = (int**)malloc(sizeof(int*) * ROWS);
    //1차원 배열 선언

    for(i = 0; i < ROWS; i++)
        a[i] = (int*)malloc(sizeof(int)*COLS);
    //2차원 선언

    for(i = 0; i < ROWS; i++)
        for(j = 0; j < COLS; j++)
            a[i][j] = i;
    //배열 초기화

#ifdef SUM_COLS     
    int sum = sum_array_cols(a);
    printf("sum_cols ... \n");
#endif

#ifdef SUM_ROWS
    printf("sum_rows ... \n");
    int sum = sum_array_rows(a);
#endif

    printf("sum = %d\n", sum);

    return 0;
}


